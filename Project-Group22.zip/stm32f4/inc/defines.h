#ifndef DEFINES_H
#define DEFINES_H

/* Put your global defines for all libraries here used in your project */

#define FATFS_SDIO_4BIT 0
#define FATFS_USE_SDIO  1
#endif
